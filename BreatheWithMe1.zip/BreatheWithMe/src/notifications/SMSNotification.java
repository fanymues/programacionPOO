package notifications;
import interfaces.Notificación;

public class SMSNotification implements Notificacion {

	private String phoneNumber;
    private String message;

    public SMSNotification(String phoneNumber, String message) {
        this.phoneNumber = phoneNumber;
        this.message = message;
    }


    public void enviar() {
        System.out.println("Enviando SMS a: " + phoneNumber);
        System.out.println("Mensaje: " + message);
    }

    // Getters y setters
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}