package sensors;

public interface PPG {
	 int leerFrecuenciaCardiaca();
}
