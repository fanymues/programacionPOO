package sensors;
import java.util.Random;

public class SensorSimuladoGSR {
	 // Simula la lectura de la respuesta galvánica (en kiloohmios)
    public double leerConductanciaPiel() {
        return 0.5 + new Random().nextDouble() * 3.0; // 0.5–3.5 kΩ
    }
}

