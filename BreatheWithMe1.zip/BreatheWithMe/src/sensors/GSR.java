package sensors;

public interface GSR {
	double leerConductanciaPiel();

}
