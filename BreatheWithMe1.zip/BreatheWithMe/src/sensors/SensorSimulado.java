package sensors;

import interfaces.SensoresArduino;
import java.util.Random;

public class SensorSimulado implements SensoresArduino {
	 public int leerFrecuenciaCardiaca() {
	        return 60 + new Random().nextInt(60);
	    }

	    public double leerConductanciaPiel() {
	        return 0.5 + new Random().nextDouble() * 3.0;
	    }
	}
