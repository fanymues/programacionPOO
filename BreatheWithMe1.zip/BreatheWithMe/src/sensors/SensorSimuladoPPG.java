package sensors;
import java.util.Random;


public class SensorSimuladoPPG {
	 // Simula la lectura del ritmo cardíaco (en BPM)
    public int leerFrecuenciaCardiaca() {
        return 60 + new Random().nextInt(60); // 60–120 bpm
    }
}

