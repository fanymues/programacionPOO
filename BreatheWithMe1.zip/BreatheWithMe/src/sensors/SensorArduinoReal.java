package sensors;


import com.fazecast.jSerialComm.SerialPort;
import java.util.Scanner;

public class SensorArduinoReal implements PPG,GSR {
	
	private SerialPort puerto;

	public boolean conectar(String nombrePuerto) {
        puerto = SerialPort.getCommPort(nombrePuerto);
        puerto.setComPortParameters(9600, 8, 1, 0); // baudrate, bits, stop, parity
        puerto.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 1000, 0);
        return puerto.openPort();
    }

	public void desconectar() {
        if (puerto != null && puerto.isOpen()) {
            puerto.closePort();
        }
    }

	 @Override
	    public int leerFrecuenciaCardiaca() {
	        String linea = leerLinea();
	        if (linea != null && linea.startsWith("PPG:")) {
	            try {
	                return Integer.parseInt(linea.split(":")[1].trim());
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        return -1; // Valor de error
	    }
	 
	 @Override
	    public double leerConductanciaPiel() {
	        String linea = leerLinea();
	        if (linea != null && linea.startsWith("GSR:")) {
	            try {
	                return Double.parseDouble(linea.split(":")[1].trim());
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        }
	        return -1.0; // Valor de error
	    }


	 private String leerLinea() {
	        if (puerto == null || !puerto.isOpen()) return null;
	        Scanner scanner = new Scanner(puerto.getInputStream());
	        return scanner.hasNextLine() ? scanner.nextLine() : null;
	    }
	}
