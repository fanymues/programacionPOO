package model;



public abstract class Usuario {
    protected String nombre;
    protected String apellidos;
    protected String correo;
    protected String telefono;
    protected String contrasena;

    public Usuario(String nombre, String apellidos, String correo, String telefono, String contrasena) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.correo = correo;
        this.telefono = telefono;
        this.contrasena = contrasena;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public String getCorreo() {
        return correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getContrasena() {
        return contrasena;
    }
    
    public abstract void displayUsuarioInfo();
}





 





