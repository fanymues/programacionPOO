package model;


	
 public class Normal extends Cliente {
 public Normal(String nombre, String correo, String contrasena) {
        super(nombre, correo, contrasena);
    }

    @Override
    public boolean tieneAccesoAPulsera() {
        return false;
 }
    	
}
