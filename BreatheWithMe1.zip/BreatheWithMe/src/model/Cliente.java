package model;

import interfaces.Escribible;
import interfaces.VisiblePorMedico;

import java.util.ArrayList;
import java.util.List;


public class Cliente extends Usuario implements Escribible, VisiblePorMedico {
	
	private List<DiarioPensamientos> diario = new ArrayList<>();
	
    public Cliente(String nombre, String apellidos, String correo, String telefono, String contrasena) {
        super(nombre, apellidos, correo, telefono, contrasena);
    }
	
	@Override
    public void escribirEntrada(String texto) {
        diario.add(new DiarioPensamientos(texto));
    }

    @Override
    public List<DiarioPensamientos> verEntradas() {
        return diario;
    }

    @Override
    public void displayUsuarioInfo() {
        System.out.println("Cliente: " + getCorreo());
    }
}

