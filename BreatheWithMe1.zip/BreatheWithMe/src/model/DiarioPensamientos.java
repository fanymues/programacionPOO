package model;


import java.time.LocalDateTime;

public class DiarioPensamientos {
	private String idUsuario;
	private String contenido;
	private String emocion;
    private LocalDateTime fecha;
    
    public DiarioPensamientos() {
    }

    public DiarioPensamientos(String idUsuario, String contenido, String emocion) {
    	 this.idUsuario = idUsuario;
         this.contenido = contenido;
         this.emocion = emocion;
         this.fecha = LocalDateTime.now();
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }

    public String getEmocion() {
        return emocion;
    }

    public void setEmocion(String emocion) {
        this.emocion = emocion;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    @Override
    public String toString() {
        return "[" + fecha + "] (" + emocion + ") " + contenido;
    }
}
