package model;


public class Cuidador extends Usuario {
    public Cuidador(String nombre, String apellidos, String correo, String telefono, String contrasena) {
        super(nombre, apellidos, correo, telefono, contrasena);
    }
    
    @Override
    public void displayUsuarioInfo() {
        System.out.println("Cuidador: " + getCorreo());
    }
}
