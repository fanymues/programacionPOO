package model;

import java.util.ArrayList;
import java.util.List;


public class Medico extends Usuario {
	
	 private List<String> correoClientesAsignados = new ArrayList<>();

    public Medico(String nombre, String apellidos, String correo, String telefono, String contrasena) {
        super(nombre, apellidos, correo, telefono, contrasena);
    }
    
    public void asignarCliente(Cliente cliente) {
        correoClientesAsignados.add(cliente.getCorreo());
    }

    public boolean tieneAccesoA(Cliente cliente) {
        return correoClientesAsignados.contains(cliente.getCorreo());
    }

    public List<String> getCorreoClientesAsignados() {
        return correoClientesAsignados;
    }

    @Override
    public void displayUsuarioInfo() {
        System.out.println("Médico: " + getCorreo());
    }
}

