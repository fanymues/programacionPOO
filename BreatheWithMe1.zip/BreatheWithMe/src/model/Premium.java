package model;

  public class Premium extends Cliente {
  public Premium(String nombre, String correo, String contrasena) {
        super(nombre, correo, contrasena);
    }

    @Override
    public boolean tieneAccesoAPulsera() {
        return true;
    }
}

 

	