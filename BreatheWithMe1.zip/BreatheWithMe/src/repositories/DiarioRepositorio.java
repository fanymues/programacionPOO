package repositories;



import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;
import java.util.List;

public class DiarioRepositorio<T> {

    private final String archivo;
    private final Type tipoLista;

    public DiarioRepositorio(String archivo, Type tipoLista) {
        this.archivo = archivo;
        this.tipoLista = tipoLista;
    }

    public List<T> cargar() {
        try (JsonReader reader = new JsonReader(new FileReader(archivo))) {
            return new Gson().fromJson(reader, tipoLista);
        } catch (IOException e) {
            return null;
        }
    }

    public void guardar(List<T> datos) {
        try (FileWriter writer = new FileWriter(archivo)) {
            new Gson().toJson(datos, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
