package repositories;

public class HistorialRepository {

}
