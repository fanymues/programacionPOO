package repositories;


import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import model.Usuario;

import java.io.*;
import java.lang.reflect.Type;
import java.util.*;

public class UsuarioRepositorio {
    private final String archivo = "usuarios.json";
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    public List<Usuario> obtenerUsuarios() {
        try (Reader reader = new FileReader(archivo)) {
            Type listType = new TypeToken<List<Usuario>>() {}.getType();
            return gson.fromJson(reader, listType);
        } catch (IOException e) {
            return new ArrayList<>();
        }
    }

    public void guardarUsuario(Usuario usuario) {
        List<Usuario> usuarios = obtenerUsuarios();
        usuarios.add(usuario);
        try (Writer writer = new FileWriter(archivo)) {
            gson.toJson(usuarios, writer);
        } catch (IOException e) {
            System.out.println("Error guardando el usuario.");
        }
    }

    public boolean correoExiste(String correo) {
        return obtenerUsuarios().stream().anyMatch(u -> u.getCorreo().equalsIgnoreCase(correo));
    }



	public Optional<Usuario> obtenerPorCorreoOTelefono(String identificador) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
