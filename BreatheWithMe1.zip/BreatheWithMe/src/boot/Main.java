package boot;

import model.Usuario;
import repositories.UsuarioRepositorio;
import services.RegistroService;
import services.LoginService;
import com.google.gson.reflect.TypeToken;
import model.*;
import repositories.DiarioRepositorio;
import services.DiarioService;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import sensors.SensorArduinoReal;
import services.EjerciciosService;
import services.ContactarCuidadorService;
import services.SensoresService;
import sensors.PPG;
import sensors.GSR;

public class Main {
    public static void main(String[] args) {
    	UsuarioRepositorio repo = new UsuarioRepositorio();
        RegistroService servicioRegistro = new RegistroService(repo);
        servicioRegistro.registrarUsuario();

        LoginService loginService = new LoginService(repo);
        Usuario sesionActiva = loginService.iniciarSesion();

        if (sesionActiva != null) {
            System.out.println("🎉 Acceso concedido al sistema.");
        } else {
            System.out.println("🔒 Acceso denegado.");
            return;
        }

        // Crear tipos
        Type tipoClientes = new TypeToken<List<Cliente>>() {}.getType();
        Type tipoMedicos = new TypeToken<List<Medico>>() {}.getType();

        // Crear repositorios
        DiarioRepositorio<Cliente> clienteRepo = new DiarioRepositorio<>("clientes.json", tipoClientes);
        DiarioRepositorio<Medico> medicoRepo = new DiarioRepositorio<>("medicos.json", tipoMedicos);

        // Cargar listas desde JSON
        List<Cliente> clientes = clienteRepo.cargar();
        List<Medico> medicos = medicoRepo.cargar();

        if (clientes == null) clientes = new ArrayList<>();
        if (medicos == null) medicos = new ArrayList<>();

        // Crear objetos de prueba
        Cliente c1 = new Cliente("Ana", "Pérez", "cliente1@mail.com", "111", "1234");
        Cliente c2 = new Cliente("Luis", "García", "cliente2@mail.com", "222", "1234");
        Medico m1 = new Medico("Dr. Juan", "Sánchez", "medico1@mail.com", "999", "abcd");

        c1.escribirEntrada("Hoy me sentí bien.");
        c1.escribirEntrada("Después del paseo, me sentí mejor.");
        c2.escribirEntrada("Me dolía la cabeza.");

        m1.asignarCliente(c1);

        clientes.add(c1);
        clientes.add(c2);
        medicos.add(m1);

        // Mostrar diarios
        DiarioService servicio = new DiarioService();
        servicio.mostrarDiario(m1, c1);
        servicio.mostrarDiario(m1, c2);

        // Guardar datos
        clienteRepo.guardar(clientes);
        medicoRepo.guardar(medicos);

        // Crear sensor real conectado a Arduino
        SensorArduinoReal sensor = new SensorArduinoReal();
        String puerto = "/dev/cu.usbserial-1410"; // Cambiar según nuestro puerto

        if (!sensor.conectar(puerto)) {
            System.out.println("❌ No se pudo conectar al Arduino en " + puerto);
            return;
        }

        // Inicializar servicios
        EjerciciosService ejerciciosService = new EjerciciosService();
        ContactarCuidadorService cuidadorService = new ContactarCuidadorService();

        // Servicio principal que detecta ataques
        SensoresService sensoresService = new SensoresService(
            sensor,  // PPG
            sensor,  // GSR
            ejerciciosService,
            cuidadorService
        );

        // Simular 5 lecturas
        for (int i = 0; i < 5; i++) {
            sensoresService.monitorear("user001");
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        // Desconectar sensor
        sensor.desconectar();
        System.out.println("🧠 Monitoreo finalizado.");
    }
}