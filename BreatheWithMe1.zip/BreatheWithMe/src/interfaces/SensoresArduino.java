package interfaces;

public interface SensoresArduino {
	int leerFrecuenciaCardiaca();
    double leerConductanciaPiel();
}


