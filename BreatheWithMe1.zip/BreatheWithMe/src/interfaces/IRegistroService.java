package interfaces;

public interface IRegistroService {
    void registrarUsuario();
}
