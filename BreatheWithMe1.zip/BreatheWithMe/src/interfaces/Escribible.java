package interfaces;

public interface Escribible {
	void escribirEntrada(String texto);

}
