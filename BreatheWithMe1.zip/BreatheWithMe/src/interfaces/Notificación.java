package interfaces;

public class Notificación {

	public interface Notificacion {
	    void enviar();
	}

}
