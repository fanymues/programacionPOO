package interfaces;



import model.Usuario;

public interface ILoginService {
    Usuario iniciarSesion();
}
