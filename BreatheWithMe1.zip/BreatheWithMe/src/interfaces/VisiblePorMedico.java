package interfaces;

import model.DiarioPensamientos;
import java.util.List;

public interface VisiblePorMedico {
	List<DiarioPensamientos> verEntradas();

}
