package utilities;


public class Validator {

    public static boolean validarCorreo(String correo) {
        return correo.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    public static boolean validarContrasena(String contrasena) {
        return contrasena.length() >= 8 && contrasena.matches(".*[a-zA-Z].*") && contrasena.matches(".*\\d.*");
    }
}
