package services;
import model.DiarioPensamientos;
import sensors.PPG;
import sensors.GSR;

public class SensoresService {
	private final PPG sensorPPG;
    private final GSR sensorGSR;
    private final EjerciciosService ejerciciosService;
    private final ContactarCuidadorService cuidadorService;
    private final HistorialService historialService;

    public SensoresService(PPG sensorPPG, GSR sensorGSR,
            EjerciciosService ejerciciosService,
            ContactarCuidadorService cuidadorService) {
this.sensorPPG = sensorPPG;
this.sensorGSR = sensorGSR;
this.ejerciciosService = ejerciciosService;
this.cuidadorService = cuidadorService;
this.historialService = new HistorialService();
}
 // Método que monitorea datos y responde si hay alerta
    public void monitorear(String idUsuario) {
        int frecuenciaCardiaca = sensorPPG.leerFrecuenciaCardiaca();
        double conductanciaPiel = sensorGSR.leerConductanciaPiel();

        System.out.println("📈 Frecuencia cardíaca: " + frecuenciaCardiaca + " bpm");
        System.out.println("💧 Conductancia de piel (GSR): " + conductanciaPiel + " kΩ");

        if (frecuenciaCardiaca > 100 && conductanciaPiel < 1.0) {
            System.out.println("⚠️ Posible ataque detectado. Activando protocolos...");

            ejerciciosService.activarEjercicioPorAtaque();
            cuidadorService.enviarAlerta("⚠️ Se ha detectado un ataque. El paciente necesita ayuda urgente.");

            DiarioPensamientos entrada = new DiarioPensamientos(
                idUsuario,
                "Se detectó un posible ataque con FC=" + frecuenciaCardiaca + " y GSR=" + conductanciaPiel,
                "ansiedad"
            );
            historialService.guardarEntrada(entrada);
        } else {
            System.out.println("✅ Estado estable.");
        }
    }
}

