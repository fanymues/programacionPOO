package services;

import interfaces.ILoginService;
import model.Usuario;
import repositories.UsuarioRepositorio;
import services.RegistroService;


import java.util.Optional;
import java.util.Scanner;

public class LoginService implements ILoginService {
    private final UsuarioRepositorio repo;
    private final Scanner scanner = new Scanner(System.in);

    public LoginService(UsuarioRepositorio repo) {
        this.repo = repo;
    }

    @Override
    public Usuario iniciarSesion() {
        System.out.println(" Iniciar sesión en Breathe With Me 🌬️");

        int intentos = 0;
        while (intentos < 3) {
            System.out.print("Introduce tu correo o número de teléfono: ");
            String identificador = scanner.nextLine();

            System.out.print("Introduce tu contraseña: ");
            String contrasena = scanner.nextLine();

            Optional<Usuario> usuarioOpt = repo.obtenerPorCorreoOTelefono(identificador);

            if (usuarioOpt.isEmpty()) {
                System.out.println("❌ Usuario no encontrado.");
                intentos++;
            } else {
                Usuario usuario = usuarioOpt.get();
                if (!usuario.getContrasena().equals(contrasena)) {
                    System.out.println("❌ Contraseña incorrecta.");
                    intentos++;
                } else {
                    System.out.println("✅ Bienvenido a Breathe With Me, " + usuario.getNombre() + " 🌬️");
                    System.out.println(" Tu tipo de usuario es: " + usuario.getClass().getSimpleName());
                    return usuario; 
                }
            }

            if (intentos < 3) {
                System.out.println("🔁 Intentos restantes: " + (3 - intentos));
            } else {
                System.out.println("🚫 Has superado el número de intentos permitidos.");
            }
        }

        return null; 
    }
}
