package services;

import java.util.List;
import java.util.ArrayList;

import com.google.gson.reflect.TypeToken;

import model.DiarioPensamientos;
import repositories.DiarioRepositorio;

public class HistorialService {
	private static final String ARCHIVO_HISTORIAL = "historial.json";
    private final DiarioRepositorio<DiarioPensamientos> repositorio;

    // Constructor: inicializa el repositorio con el archivo y tipo correspondiente
    public HistorialService() {
        this.repositorio = new DiarioRepositorio<>(
            ARCHIVO_HISTORIAL,
            new TypeToken<List<DiarioPensamientos>>() {}.getType()
        );
    }

    // Guarda una nueva entrada en el historial
    public void guardarEntrada(DiarioPensamientos nuevaEntrada) {
        List<DiarioPensamientos> historial = repositorio.cargar();
        if (historial == null) {
            historial = new ArrayList<>();
        }
        historial.add(nuevaEntrada);
        repositorio.guardar(historial);
    }

    // Devuelve el historial completo de un usuario
    public List<DiarioPensamientos> obtenerHistorialPorUsuario(String idUsuario) {
        List<DiarioPensamientos> historial = repositorio.cargar();
        List<DiarioPensamientos> resultado = new ArrayList<>();

        if (historial != null) {
            for (DiarioPensamientos entrada : historial) {
                if (entrada.getIdUsuario().equals(idUsuario)) {
                    resultado.add(entrada);
                }
            }
        }

        return resultado;
    }

    // Filtra las entradas del historial de un usuario por emoción
    public List<DiarioPensamientos> filtrarPorEmocion(String idUsuario, String emocion) {
        List<DiarioPensamientos> historialUsuario = obtenerHistorialPorUsuario(idUsuario);
        List<DiarioPensamientos> filtrado = new ArrayList<>();

        for (DiarioPensamientos entrada : historialUsuario) {
            if (entrada.getEmocion().equalsIgnoreCase(emocion)) {
                filtrado.add(entrada);
            }
        }

        return filtrado;
    }
}
