package services;
import java.util.ArrayList;
import java.util.List;

public class EjerciciosService {
public static class Ejercicio {
	
	        private String nombre;
	        private String descripcion;
	        private int duracionSegundos;
	        private boolean incluyeMusica;

	        public Ejercicio(String nombre, String descripcion, int duracionSegundos, boolean incluyeMusica) {
	            this.nombre = nombre;
	            this.descripcion = descripcion;
	            this.duracionSegundos = duracionSegundos;
	            this.incluyeMusica = incluyeMusica;
	        }

	        public String getNombre() {
	            return nombre;
	        }

	        public String getDescripcion() {
	            return descripcion;
	        }

	        public int getDuracionSegundos() {
	            return duracionSegundos;
	        }

	        public boolean isIncluyeMusica() {
	            return incluyeMusica;
	        }
	    }

	    private List<Ejercicio> ejerciciosDisponibles;

	    public EjerciciosService() {
	        ejerciciosDisponibles = new ArrayList<>();
	        cargarEjerciciosIniciales();
	    }

	    private void cargarEjerciciosIniciales() {
	        ejerciciosDisponibles.add(new Ejercicio(
	                "Respiración 4-4-4-4",
	                "Inhala 4 segundos, mantén 4 segundos, exhala 4 segundos, mantén 4 segundos. Acompañado de música relajante.",
	                60,
	                true
	        ));
	    }

	    public List<Ejercicio> getEjerciciosDisponibles() {
	        return ejerciciosDisponibles;
	    }

	    public Ejercicio obtenerEjercicioPorNombre(String nombre) {
	        for (Ejercicio e : ejerciciosDisponibles) {
	            if (e.getNombre().equalsIgnoreCase(nombre)) {
	                return e;
	            }
	        }
	        return null;
	    }

	    // Método para activar automáticamente el ejercicio cuando se detecta un ataque
	    public Ejercicio activarEjercicioPorAtaque() {
	        System.out.println("⚠️ Ataque detectado: Activando ejercicio de respiración. ");
	        return obtenerEjercicioPorNombre("Respiración 4-4-4-4");
	    }
	}

