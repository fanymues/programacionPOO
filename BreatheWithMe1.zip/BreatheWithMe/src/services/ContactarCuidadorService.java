package services;

public class ContactarCuidadorService {
	
	    // Datos del cuidador (simulación)
	    private String nombreCuidador;
	    private String numeroTelefono;
	    private String email;

	    // Constructor
	    public ContactarCuidadorService(String nombreCuidador, String numeroTelefono, String email) {
	        this.nombreCuidador = nombreCuidador;
	        this.numeroTelefono = numeroTelefono;
	        this.email = email;
	    }

	    // Método para enviar alerta al cuidador
	    public void enviarAlerta(String mensaje) {
	        // Simula el envío del mensaje
	        System.out.println("📡 Enviando alerta al cuidador...");
	        System.out.println("👤 Cuidador: " + nombreCuidador);
	        System.out.println("📞 Teléfono: " + numeroTelefono);
	        System.out.println("📧 Email: " + email);
	        System.out.println("📩 Mensaje: " + mensaje);
	    }

	    // Getters y setters si se necesitan
	    public String getNombreCuidador() {
	        return nombreCuidador;
	    }

	    public void setNombreCuidador(String nombreCuidador) {
	        this.nombreCuidador = nombreCuidador;
	    }

	    public String getNumeroTelefono() {
	        return numeroTelefono;
	    }

	    public void setNumeroTelefono(String numeroTelefono) {
	        this.numeroTelefono = numeroTelefono;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }
	    public ContactarCuidadorService() {
	        // se puede dejar vacio
	    }
	}
