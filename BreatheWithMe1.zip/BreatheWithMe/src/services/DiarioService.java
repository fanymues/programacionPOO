package services;

import model.Cliente;
import model.DiarioPensamientos;
import model.Medico;

public class DiarioService {

    public void escribirEntrada(Cliente cliente, String contenido) {
        cliente.escribirEntrada(contenido);
    }

    public void mostrarDiario(Medico medico, Cliente cliente) {
        if (!medico.tieneAccesoA(cliente)) {
            System.out.println("⛔ Acceso denegado al diario de " + cliente.getCorreo());
            return;
        }

        System.out.println("📖 Diario de " + cliente.getCorreo());
        for (DiarioPensamientos entrada : cliente.verEntradas()) {
            System.out.println(" - " + entrada);
        }
    }
}
