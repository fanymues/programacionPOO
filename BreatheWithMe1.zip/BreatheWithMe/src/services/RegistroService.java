package services;


import interfaces.IRegistroService;
import model.*;
import repositories.UsuarioRepositorio;
import utilities.Validator;

import java.util.Scanner;

public class RegistroService implements IRegistroService {
    private final UsuarioRepositorio repo;
    private final Scanner scanner = new Scanner(System.in);

    public RegistroService(UsuarioRepositorio repo) {
        this.repo = repo;
    }

    @Override
    public void registrarUsuario() {
        System.out.println("Selecciona tipo de usuario: 1. Cliente | 2. Cuidador | 3. Médico");
        String tipo = scanner.nextLine();

        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();

        System.out.print("Apellidos: ");
        String apellidos = scanner.nextLine();

        String correo, confirmarCorreo;
        do {
            System.out.print("Correo: ");
            correo = scanner.nextLine();

            System.out.print("Confirma el correo: ");
            confirmarCorreo = scanner.nextLine();

            if (!correo.equals(confirmarCorreo)) {
                System.out.println("❌ Los correos no coinciden.");
            } else if (!Validator.validarCorreo(correo)) {
                System.out.println("❌ Formato de correo inválido.");
                confirmarCorreo = ""; // forzar repetición
            } else if (repo.correoExiste(correo)) {
                System.out.println("❌ Este correo ya está registrado.");
                return;
            }
        } while (!correo.equals(confirmarCorreo));

        System.out.print("Número de teléfono: ");
        String telefono = scanner.nextLine();

        String contrasena, confirmarContrasena;
        do {
            System.out.print("Contraseña (mínimo 8 caracteres, letras y números): ");
            contrasena = leerContrasena();

            System.out.print("Confirma la contraseña: ");
            confirmarContrasena = leerContrasena();

            if (!contrasena.equals(confirmarContrasena)) {
                System.out.println("❌ Las contraseñas no coinciden.");
            } else if (!Validator.validarContrasena(contrasena)) {
                System.out.println("❌ La contraseña no cumple los requisitos.");
                confirmarContrasena = ""; // forzar repetición
            }
        } while (!contrasena.equals(confirmarContrasena));

        Usuario nuevoUsuario = switch (tipo) {
            case "1" -> new Cliente(nombre, apellidos, correo, telefono, contrasena);
            case "2" -> new Cuidador(nombre, apellidos, correo, telefono, contrasena);
            case "3" -> new Medico(nombre, apellidos, correo, telefono, contrasena);
            default -> {
                System.out.println("❌ Tipo de usuario no válido.");
                yield null;
            }
        };

        if (nuevoUsuario != null) {
            repo.guardarUsuario(nuevoUsuario);
            System.out.println("✅ Usuario registrado correctamente.");
        }
    }

    // Eclipse no permite ocultar input con asteriscos sin consola, así que usamos Scanner
    private String leerContrasena() {
        return scanner.nextLine();
    }
}
