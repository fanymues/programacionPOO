package gui;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ClienteGUI extends JFrame {
	private JTextField campoUsuario;
    private JPasswordField campoContrasena;
    private JLabel mensajeEstado;

    public ClienteGUI() {
        setTitle("Breathe With Me - Inicio de Sesión");
        setSize(400, 250);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(5, 1));

        campoUsuario = new JTextField();
        campoContrasena = new JPasswordField();
        mensajeEstado = new JLabel("", SwingConstants.CENTER);

        JButton botonLogin = new JButton("Iniciar sesión");
        JButton botonRegistro = new JButton("Registrarse");

        add(new JLabel("Usuario:", SwingConstants.CENTER));
        add(campoUsuario);
        add(new JLabel("Contraseña:", SwingConstants.CENTER));
        add(campoContrasena);

        JPanel panelBotones = new JPanel();
        panelBotones.add(botonLogin);
        panelBotones.add(botonRegistro);
        add(panelBotones);
        add(mensajeEstado);

        botonLogin.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String usuario = campoUsuario.getText();
                String contrasena = new String(campoContrasena.getPassword());
                // Aquí puedes conectar con LoginService para validar
                if (usuario.equals("admin") && contrasena.equals("1234")) {
                    mensajeEstado.setText("✅ Inicio de sesión exitoso");
                    // abrirPantallaPrincipal(); // función futura
                } else {
                    mensajeEstado.setText("❌ Usuario o contraseña incorrectos");
                }
            }
        });

        botonRegistro.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                mensajeEstado.setText("👉 Registro de usuario no implementado aún");
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new ClienteGUI();
    }
}


