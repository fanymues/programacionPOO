package menu;

import java.util.Scanner;

import model.Medico;
import services.HistorialService;

public class MenuMedico {
    private final Medico medico;
    private final Scanner scanner;
    private final HistorialService historialService;

    public MenuMedico(Medico medico) {
        this.medico = medico;
        this.scanner = new Scanner(System.in);
        this.historialService = new HistorialService();
    }

    public void mostrar() {
        while (true) {
            System.out.println("\n=== MENÚ MÉDICO ===");
            System.out.println("1. Ver historial de paciente");
            System.out.println("2. Generar reporte estadístico");
            System.out.println("3. Cerrar sesión");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    verHistorialPaciente();
                    break;
                case 2:
                    generarReporte();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    private void verHistorialPaciente() {
        System.out.print("\nID del paciente: ");
        String pacienteId = scanner.nextLine();
        List<HistorialEntry> historial = historialService.obtenerPorUsuario(pacienteId);
        
        System.out.println("\n--- HISTORIAL DEL PACIENTE ---");
        historial.forEach(episodio -> System.out.println(episodio));
    }
}
