package menu;

import java.util.Scanner;

import model.Cliente;
import services.DiarioService;
import services.HistorialService;

public class MenuCliente {
    private final Cliente cliente;
    private final Scanner scanner;
    private final HistorialService historialService;
    private final DiarioService diarioService;

    public MenuCliente(Cliente cliente) {
        this.cliente = cliente;
        this.scanner = new Scanner(System.in);
        this.historialService = new HistorialService();
        this.diarioService = new DiarioService();
    }

    public void mostrar() {
        while (true) {
            System.out.println("\n=== MENÚ CLIENTE ===");
            System.out.println("1. Registrar episodio de ansiedad");
            System.out.println("2. Ver mi historial");
            System.out.println("3. Escribir en el diario");
            System.out.println("4. Cerrar sesión");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    registrarEpisodio();
                    break;
                case 2:
                    verHistorial();
                    break;
                case 3:
                    escribirDiario();
                    break;
                case 4:
                    return; // Volver al menú principal
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    private void registrarEpisodio() {
        System.out.print("\nTipo de episodio (ataque/ansiedad): ");
        String tipo = scanner.nextLine();
        System.out.print("Intensidad (1-10): ");
        int intensidad = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Notas: ");
        String notas = scanner.nextLine();

        historialService.registrarEpisodio(cliente.getCorreo(), tipo, intensidad, notas);
        System.out.println("Episodio registrado exitosamente.");
    }

    private void verHistorial() {
        System.out.println("\n--- MI HISTORIAL ---");
        historialService.obtenerPorUsuario(cliente.getCorreo()).forEach(episodio -> {
            System.out.printf(
                "[%s] %s - Intensidad: %d\nNotas: %s\n\n",
                episodio.getFecha(),
                episodio.getTipoEpisodio(),
                episodio.getIntensidad(),
                episodio.getNotas()
            );
        });
    }

    private void escribirDiario() {
        System.out.println("\n--- DIARIO ---");
        System.out.println("Pregunta sugerida: ¿Qué desencadenó tu ansiedad hoy?");
        System.out.print("Escribe tu entrada: ");
        String texto = scanner.nextLine();
        diarioService.guardarEntrada(cliente.getCorreo(), texto);
        System.out.println("Entrada guardada.");
    }
}
