package menu;

import java.util.Scanner;

import javax.security.sasl.AuthenticationException;

import model.Cliente;
import model.Cuidador;
import model.Medico;
import model.Usuario;
import services.LoginService;

public class MenuPrincipal {
    private static final Scanner scanner = new Scanner(System.in);
    private static final LoginService loginService = new LoginService(null);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== BIENVENIDO A BREATHE WITH ME ===");
            System.out.println("1. Iniciar sesión");
            System.out.println("2. Registrarse");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine(); // Limpiar buffer

            switch (opcion) {
                case 1:
                    iniciarSesion();
                    break;
                case 2:
                    registrarse();
                    break;
                case 3:
                    System.out.println("¡Hasta pronto!");
                    System.exit(0);
                default:
                    System.out.println("Opción inválida. Intente nuevamente.");
            }
        }
    }

    private static void iniciarSesion() {
        System.out.print("\nUsuario: ");
        String usuario = scanner.nextLine();
        System.out.print("Contraseña: ");
        String contraseña = scanner.nextLine();

        try {
            Usuario user = loginService.autenticar(usuario, contraseña);
            redirigirSegunRol(user);
        } catch (AuthenticationException e) {
            System.out.println("Error: " + e.getMessage());
	        }
	    }

	    private static void redirigirSegunRol(Usuario user) {
	        if (user instanceof Cliente) {
	            new MenuCliente((Cliente) user).mostrar();
	        } else if (user instanceof Medico) {
	            new MenuMedico((Medico) user).mostrar();
	        } else if (user instanceof Cuidador) {
	            new MenuCuidador((Cuidador) user).mostrar();
	        }
	    }
	}
