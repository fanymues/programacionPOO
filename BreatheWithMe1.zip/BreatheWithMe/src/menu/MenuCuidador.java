package menu;

import java.util.Scanner;

import model.Cuidador;

public class MenuCuidador {
    private final Cuidador cuidador;
    private final Scanner scanner;
    private final NotificacionesService notificacionesService;

    public MenuCuidador(Cuidador cuidador) {
        this.cuidador = cuidador;
        this.scanner = new Scanner(System.in);
        this.notificacionesService = new NotificacionesService();
    }

    public void mostrar() {
        while (true) {
            System.out.println("\n=== MENÚ CUIDADOR ===");
            System.out.println("1. Ver notificaciones");
            System.out.println("2. Configurar alertas");
            System.out.println("3. Cerrar sesión");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1:
                    verNotificaciones();
                    break;
                case 2:
                    configurarAlertas();
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Opción inválida.");
            }
        }
    }

    private void verNotificaciones() {
        System.out.println("\n--- NOTIFICACIONES ---");
        notificacionesService.obtenerParaCuidador(cuidador.getId()).forEach(notif -> {
            System.out.printf(
                "[%s] %s - Paciente: %s\n",
                notif.getFecha(),
                notif.getMensaje(),
                notif.getPacienteId()
            );
        });
    }
}